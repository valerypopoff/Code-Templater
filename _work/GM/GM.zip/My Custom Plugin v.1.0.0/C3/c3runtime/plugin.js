"use strict";

	var __CONSTRUCT2_RUNTIME2__ = false;
	var __CONSTRUCT3_RUNTIME2__ = false;
	var __CONSTRUCT3_RUNTIME3__ = true;

{
	C3.Plugins.MyCustomPlugin = class MyCustomPluginPlugin extends C3.SDKPluginBase
	{
		constructor(opts)
		{
			super(opts);
		}
		
		Release()
		{
			super.Release();
		}
	};
}