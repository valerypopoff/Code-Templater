"use strict";

{
	const PLUGIN_CLASS = SDK.Plugins.MyCustomPlugin;

	// Ignore this: yes
	PLUGIN_CLASS.Instance = class MyCustomPluginInstance extends SDK.IInstanceBase

	{
		constructor(sdkType, inst)
		{
			super(sdkType, inst);
		}
		
		Release()
		{
		}
		
		OnCreate()
		{
		}
		
		OnPropertyChanged(id, value)
		{
		}
		
		LoadC2Property(name, valueString)
		{
			return false;		// not handled
		}
	};
}